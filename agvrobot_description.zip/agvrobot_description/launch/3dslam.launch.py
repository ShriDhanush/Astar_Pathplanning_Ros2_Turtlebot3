from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import ThisLaunchFileDir, LaunchConfiguration
from launch.substitutions import PathJoinSubstitution
from launch.actions import ExecuteProcess
import os
import xacro
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():

    share_dir = get_package_share_directory('agvrobot_description')

    xacro_file = os.path.join(share_dir, 'urdf', 'agvrobot.xacro')
    robot_description_config = xacro.process_file(xacro_file)
    robot_urdf = robot_description_config.toxml()
    
    world = os.path.join(
        get_package_share_directory('agvrobot_description'),
        'worlds',
        'restaurant.world'
    )   
    
    use_sim_time = LaunchConfiguration('use_sim_time', default='true')

    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        parameters=[
            {'robot_description': robot_urdf},
            {'use_sim_time': use_sim_time}
        ]
    )

    joint_state_publisher_node = Node(
        package='joint_state_publisher',
        executable='joint_state_publisher',
        name='joint_state_publisher',
        parameters=[
            {'use_sim_time': use_sim_time}
        ]
    )

    gazebo_server = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('gazebo_ros'),
                'launch',
                'gzserver.launch.py'
            ])
        ]),
        launch_arguments={
            'world': world,
            'pause': 'true'
        }.items()
    )

    gazebo_client = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('gazebo_ros'),
                'launch',
                'gzclient.launch.py'
            ])
        ])
    )

    urdf_spawn_node = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=[
            '-entity', 'agvrobot',
            '-topic', 'robot_description'
        ],
        output='screen'
    )

    teleop_twist_keyboard_node = Node(
        package='teleop_twist_keyboard',
        executable='teleop_twist_keyboard',
        name='teleop_twist_keyboard',
        output='screen',
        prefix='xterm -e',  # This opens a new terminal for teleop input
        remappings=[('/cmd_vel', '/cmd_vel')]  # Ensure the topic matches your robot's command topic
    )

    slam_toolbox_node = Node(
        package='slam_toolbox',
        executable='async_slam_toolbox_node',
        name='slam_toolbox',
        output='screen',
        parameters=[
            os.path.join(
                get_package_share_directory('agvrobot_description'),
                'config',
                'mapper_params_online_async.yaml'
            )
        ],
        remappings=[
            ('/scan', '/laser_controller/out'),
            ('/odom', '/odom')
        ]
    )

    # RTAB-Map nodes
    rtabmap_rgbd_node = Node(
        package='rtabmap_ros',
        executable='rgbd_sync',
        name='rtabmap_rgbd_sync',
        output='screen',
        parameters=[
            os.path.join(
                get_package_share_directory('agvrobot_description'),
                'config',
                'rtabmap_rgbd_params.yaml'
            )
        ],
        remappings=[
            ('/camera/depth/image_raw', '/camera/depth/image_raw'),
            ('/camera/rgb/image_raw', '/camera/rgb/image_raw'),
            ('/camera/depth/camera_info', '/camera/depth/camera_info'),
            ('/camera/rgb/camera_info', '/camera/rgb/camera_info'),
            ('/rtabmap/odom', '/odom')
        ]
    )

    rtabmap_mapping_node = Node(
        package='rtabmap_ros',
        executable='rtabmap',
        name='rtabmap',
        output='screen',
        parameters=[
            os.path.join(
                get_package_share_directory('agvrobot_description'),
                'config',
                'rtabmap_params.yaml'
            )
        ],
        remappings=[
            ('/rtabmap/odom', '/odom'),
            ('/rtabmap/scan', '/scan')
        ]
    )

    return LaunchDescription([
        robot_state_publisher_node,
        joint_state_publisher_node,
        gazebo_server,
        gazebo_client,
        urdf_spawn_node,
        teleop_twist_keyboard_node,
        slam_toolbox_node,
        rtabmap_rgbd_node,
        rtabmap_mapping_node
    ])

