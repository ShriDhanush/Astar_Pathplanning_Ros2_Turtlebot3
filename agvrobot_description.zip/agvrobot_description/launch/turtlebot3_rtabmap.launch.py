from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='turtlebot3_gazebo',
            executable='turtlebot3_world',
            name='turtlebot3_world',
            output='screen'
        ),
        Node(
            package='turtlebot3_gazebo',
            executable='spawn_turtlebot3',
            name='spawn_turtlebot3',
            output='screen'
        ),
        Node(
            package='rtabmap_ros',
            executable='rtabmap',
            name='rtabmap',
            output='screen',
            parameters=[{
                'frame_id': 'base_link',
                'subscribe_depth': False,  # Set to True if using depth images
                'subscribe_scan': True,  # Make sure this is true for using LiDAR
                'scan_topic': '/velodyne_points',  # The LiDAR topic
            }]
        ),
    ])

