import numpy as np
import matplotlib.pyplot as plt
import cv2

show_animation = True

class BugPlanner:
    def __init__(self, start, goal, grid):
        self.start = start
        self.goal = goal
        self.grid = grid
        self.r_x = [start[0]]
        self.r_y = [start[1]]
        self.out_x, self.out_y = self.get_obstacle_coordinates()
        self.dist_threshold = 1.0  # Distance threshold to stay close to the wall
        self.visited_obstacles = set()  # Store visited obstacle points to avoid loops
        self.backtracking = False  # Used to manage backtracking if stuck

    def get_obstacle_coordinates(self):
        obs_x, obs_y = [], []
        for i in range(self.grid.shape[0]):
            for j in range(self.grid.shape[1]):
                if self.grid[i, j] == 1:  # Assuming 1 indicates an obstacle
                    obs_x.append(i)
                    obs_y.append(j)
        return obs_x, obs_y

    def mov_normal(self):
        """Move in the direction of the goal."""
        return self.r_x[-1] + np.sign(self.goal[0] - self.r_x[-1]), \
               self.r_y[-1] + np.sign(self.goal[1] - self.r_y[-1])

    def mov_to_next_obs(self, visited_x, visited_y):
        """Move along the obstacle boundary."""
        directions = [(1, 0), (0, 1), (-1, 0), (0, -1), (1, 1), (-1, -1), (-1, 1), (1, -1)]  # Add diagonal directions too
        for add_x, add_y in directions:
            c_x, c_y = self.r_x[-1] + add_x, self.r_y[-1] + add_y
            if 0 <= c_x < self.grid.shape[0] and 0 <= c_y < self.grid.shape[1]:  # Ensure it's within the grid
                if self.grid[c_x, c_y] == 0 and (c_x, c_y) not in zip(visited_x, visited_y):  # Move to free space
                    return c_x, c_y, False
        return self.r_x[-1], self.r_y[-1], True  # No valid move found, stay in place

    def is_stuck(self):
        """Check if the robot is stuck in the same place (over a series of steps)."""
        if len(self.r_x) > 10:  # Check the last 10 movements
            return self.r_x[-1] == self.r_x[-5] and self.r_y[-1] == self.r_y[-5]
        return False

    def distance_to_goal(self):
        """Calculate the Euclidean distance to the goal."""
        return np.linalg.norm(np.array([self.r_x[-1], self.r_y[-1]]) - np.array(self.goal))

    def can_leave_obstacle(self):
        """Check if the robot can leave the obstacle and move directly towards the goal."""
        cand_x, cand_y = self.mov_normal()
        if 0 <= cand_x < self.grid.shape[0] and 0 <= cand_y < self.grid.shape[1]:
            if self.grid[cand_x, cand_y] == 0:  # Check if the direction is free of obstacles
                return True
        return False

    def bug1(self):
        mov_dir = 'normal'
        exit_x, exit_y = -np.inf, -np.inf
        dist = np.inf
        second_round = False
        visited_x, visited_y = [], []
        recovery_mode = False

        if show_animation:
            plt.plot(self.out_x, self.out_y, ".k")
            plt.plot(self.r_x[-1], self.r_y[-1], "og")
            plt.plot(self.goal[0], self.goal[1], "xb")
            plt.grid(True)
            plt.title('BUG 1')

        while True:
            if (self.r_x[-1], self.r_y[-1]) == self.goal:
                print("Goal reached!")
                break

            if mov_dir == 'normal' and not recovery_mode:  # Free movement toward the goal
                cand_x, cand_y = self.mov_normal()
                if self.grid[cand_x, cand_y] == 1:  # Hit an obstacle
                    mov_dir = 'obs'  # Switch to obstacle following mode
                    visited_x.append(cand_x)
                    visited_y.append(cand_y)
                    recovery_mode = False  # Exit recovery mode
                else:
                    self.r_x.append(cand_x)
                    self.r_y.append(cand_y)

            elif mov_dir == 'obs':  # Obstacle following mode
                cand_x, cand_y, back_to_start = self.mov_to_next_obs(visited_x, visited_y)
                visited_x.append(cand_x)
                visited_y.append(cand_y)
                self.r_x.append(cand_x)
                self.r_y.append(cand_y)

                # Check distance to goal
                d = np.linalg.norm(np.array([cand_x, cand_y]) - np.array(self.goal))
                if d < dist and not second_round:
                    exit_x, exit_y = cand_x, cand_y
                    dist = d

                # If back to starting point near obstacle
                if back_to_start and not second_round:
                    second_round = True

                # If we reach the exit point, go back to free movement
                if (cand_x, cand_y) == (exit_x, exit_y) and second_round:
                    mov_dir = 'normal'

            # Check if stuck and enter recovery mode
            if self.is_stuck():
                print("Stuck! Trying recovery mode...")
                recovery_mode = True
                mov_dir = 'obs'  # Switch to obstacle mode
                self.backtracking = True  # Enable backtracking
                # Try to move in another direction along the boundary

            if recovery_mode:
                mov_dir = 'obs'  # Stay in obstacle following until unstuck

            if show_animation:
                plt.plot(self.r_x, self.r_y, "-r")
                plt.pause(0.001)

        if show_animation:
            plt.show()


def main():
    # Load your map and convert to a grid
    img = cv2.imread('/home/dhanush/ros2_ws/src/agvrobot_description/agvrobot_description/maze.pgm', cv2.IMREAD_GRAYSCALE)  # Load your map
    _, binary_map = cv2.threshold(img, 127, 1, cv2.THRESH_BINARY_INV)  # Convert to binary (0 for free space, 1 for obstacle)
    grid = binary_map  # Your grid representation

    # Define start and goal positions
    start = (46, 20)  # Replace with your actual start coordinates
    goal = (215, 50)  # Replace with your actual goal coordinates

    my_Bug = BugPlanner(start, goal, grid)
    my_Bug.bug1()


if __name__ == '__main__':
    main()

