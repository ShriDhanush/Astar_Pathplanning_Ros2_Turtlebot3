#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from math import sqrt, pow, pi

class PID:
    def __init__(self, kp, ki, kd):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.previous_error = 0.0
        self.integral = 0.0

    def calculate(self, error, dt):
        derivative = (error - self.previous_error) / dt if dt > 0 else 0.0
        self.integral += error * dt
        output = self.kp * error + self.ki * self.integral + self.kd * derivative
        self.previous_error = error
        return output

class TrianglePathNode(Node):
    def __init__(self):
        super().__init__('triangle_path_node')

        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)
        self.odom_subscription = self.create_subscription(
            Odometry, '/odom', self.odom_callback, 10)

        self.state = 'MOVE_FORWARD'
        self.current_position = [0.0, 0.0]
        self.current_orientation = 0.0
        self.initial_position = [0.0, 0.0]
        self.initial_orientation = 0.0
        self.move_distance = 2.0  # Adjust as needed
        self.turn_angle = 2 * pi / 3  # 120 degrees in radians for a triangle
        self.turns_completed = 0

        # PID Controllers for linear and angular control
        self.linear_pid = PID(kp=1.0, ki=0.0, kd=0.1)
        self.angular_pid = PID(kp=1.0, ki=0.0, kd=0.1)

        # Time variables for PID calculation
        self.previous_time = self.get_clock().now()

        # Timer to control the main loop
        self.timer = self.create_timer(0.1, self.timer_callback)

    def odom_callback(self, msg):
        self.current_position = [msg.pose.pose.position.x, msg.pose.pose.position.y]

        orientation_q = msg.pose.pose.orientation
        yaw = self.euler_from_quaternion(
            orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w)
        self.current_orientation = yaw

    def euler_from_quaternion(self, x, y, z, w):
        import math
        siny_cosp = 2.0 * (w * z + x * y)
        cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
        yaw = math.atan2(siny_cosp, cosy_cosp)
        return yaw

    def distance_traveled(self):
        return sqrt(
            pow((self.current_position[0] - self.initial_position[0]), 2) +
            pow((self.current_position[1] - self.initial_position[1]), 2)
        )

    def angle_difference(self, target_angle, current_angle):
        diff = (target_angle - current_angle + pi) % (2 * pi) - pi
        return diff

    def timer_callback(self):
        msg = Twist()
        current_time = self.get_clock().now()
        dt = (current_time - self.previous_time).nanoseconds / 1e3
        self.previous_time = current_time

        if self.state == 'MOVE_FORWARD':
            distance_error = self.move_distance - self.distance_traveled()

            if distance_error > 0.01:
                linear_velocity = self.linear_pid.calculate(distance_error, dt)
                msg.linear.x = min(linear_velocity, 0.3)
                msg.angular.z = 0.0
            else:
                msg.linear.x = 0.0
                self.state = 'TURN'
                self.initial_orientation = self.current_orientation
                self.get_logger().info(f'Completed side {self.turns_completed + 1}')

        elif self.state == 'TURN':
            target_orientation = self.initial_orientation + self.turn_angle
            angle_error = self.angle_difference(target_orientation, self.current_orientation)

            if abs(angle_error) > 0.01:
                angular_velocity = self.angular_pid.calculate(angle_error, dt)
                msg.linear.x = 0.0
                msg.angular.z = max(min(angular_velocity, 0.5), -0.5)
            else:
                msg.angular.z = 0.0
                self.state = 'MOVE_FORWARD'
                self.turns_completed += 1
                self.initial_position = self.current_position

                if self.turns_completed >= 4:
                    self.get_logger().info('Completed triangular path')
                    self.destroy_node()
                    rclpy.shutdown()

        self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    triangle_path_node = TrianglePathNode()
    rclpy.spin(triangle_path_node)

if __name__ == '__main__':
    main()

