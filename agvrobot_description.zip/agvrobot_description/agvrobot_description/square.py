#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from math import sqrt, pow, atan2, pi

class SquarePathNode(Node):
    def __init__(self):
        super().__init__('square_path_node')
        

        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)
        

        self.odom_subscription = self.create_subscription(
            Odometry, '/odom', self.odom_callback, 10)
        

        self.state = 'MOVE_FORWARD'
        self.current_position = [0.0, 0.0]
        self.current_orientation = 0.0
        self.initial_position = [0.0, 0.0]
        self.initial_orientation = 0.0
        self.move_distance = 2.0  
        self.turn_angle = pi / 2  
        self.turns_completed = 0
        

        self.timer = self.create_timer(0.1, self.timer_callback)
        
    def odom_callback(self, msg):

        self.current_position = [msg.pose.pose.position.x, msg.pose.pose.position.y]
        

        orientation_q = msg.pose.pose.orientation
        _, _, yaw = self.euler_from_quaternion(orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w)
        self.current_orientation = yaw

    def euler_from_quaternion(self, x, y, z, w):
        """
        Convert quaternion (x, y, z, w) to euler angles (roll, pitch, yaw).
        We only need yaw for 2D movement.
        """
        import math
        t3 = +2.0 * (w * z + x * y)
        t4 = +1.0 - 2.0 * (y * y + z * z)
        yaw = math.atan2(t3, t4)
        return 0.0, 0.0, yaw  

    def distance_traveled(self):
        """Calculate the Euclidean distance between initial and current position."""
        return sqrt(pow((self.current_position[0] - self.initial_position[0]), 2) +
                    pow((self.current_position[1] - self.initial_position[1]), 2))

    def angle_turned(self):
        """Calculate the angle turned since the initial orientation."""
        return abs(self.current_orientation - self.initial_orientation)

    def timer_callback(self):
        msg = Twist()
        
        if self.state == 'MOVE_FORWARD':

            if self.distance_traveled() < self.move_distance:
                msg.linear.x = 0.3  
                msg.angular.z = 0.0
            else:

                msg.linear.x = 0.0
                msg.angular.z = 0.0
                self.state = 'TURN'
                self.initial_orientation = self.current_orientation 
                self.get_logger().info(f'Finished moving forward: {self.current_position}')
        
        elif self.state == 'TURN':

            if self.angle_turned() < self.turn_angle:
                msg.linear.x = 0.0
                msg.angular.z = 0.5
            else:

                msg.linear.x = 0.0
                msg.angular.z = 0.0
                self.state = 'MOVE_FORWARD'
                self.turns_completed += 1
                self.initial_position = self.current_position  
                self.get_logger().info(f'Finished turning: {self.current_orientation}')
                
                if self.turns_completed >= 5:

                    self.get_logger().info('Completed square path')
                    self.destroy_node()
                    rclpy.shutdown()


        self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    square_path_node = SquarePathNode()
    rclpy.spin(square_path_node)

if __name__ == '__main__':
    main()

