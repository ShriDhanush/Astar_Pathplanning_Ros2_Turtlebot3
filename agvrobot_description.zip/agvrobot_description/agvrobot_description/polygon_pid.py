#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from math import sqrt, pow, atan2, pi
import time

class PID:
    def __init__(self, p, i, d):
        self.p = p
        self.i = i
        self.d = d
        self.previous_error = 0
        self.integral = 0

    def compute(self, setpoint, measured_value):
        error = setpoint - measured_value
        self.integral += error
        derivative = error - self.previous_error
        output = self.p * error + self.i * self.integral + self.d * derivative
        self.previous_error = error
        return output

class PolygonPathNode(Node):
    def __init__(self, num_sides, side_length):
        super().__init__('polygon_path_node')

        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)
        self.odom_subscription = self.create_subscription(
            Odometry, '/odom', self.odom_callback, 10)

        self.num_sides = num_sides
        self.side_length = side_length
        self.turn_angle = 2 * pi / num_sides
        self.state = 'MOVE_FORWARD'
        self.current_position = [0.0, 0.0]
        self.current_orientation = 0.0
        self.initial_position = [0.0, 0.0]
        self.initial_orientation = 0.0
        self.sides_completed = 0

        self.linear_pid = PID(1.0, 0.0, 0.1)  # Adjust P, I, D for linear movement
        self.angular_pid = PID(1.0, 0.0, 0.1)  # Adjust P, I, D for angular movement

        self.timer = self.create_timer(0.1, self.timer_callback)

    def odom_callback(self, msg):
        self.current_position = [msg.pose.pose.position.x, msg.pose.pose.position.y]

        orientation_q = msg.pose.pose.orientation
        _, _, yaw = self.euler_from_quaternion(orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w)
        self.current_orientation = yaw

    def euler_from_quaternion(self, x, y, z, w):
        import math
        t3 = +2.0 * (w * z + x * y)
        t4 = +1.0 - 2.0 * (y * y + z * z)
        yaw = math.atan2(t3, t4)
        return 0.0, 0.0, yaw

    def distance_traveled(self):
        return sqrt(pow((self.current_position[0] - self.initial_position[0]), 2) +
                    pow((self.current_position[1] - self.initial_position[1]), 2))

    def angle_turned(self):
        return abs(self.current_orientation - self.initial_orientation)

    def timer_callback(self):
        msg = Twist()

        if self.state == 'MOVE_FORWARD':
            distance_error = self.side_length - self.distance_traveled()
            msg.linear.x = self.linear_pid.compute(self.side_length, self.distance_traveled())
            msg.angular.z = 0.0

            if distance_error <= 0.05:  # Tolerance for stopping
                msg.linear.x = 0.0
                self.state = 'TURN'
                self.initial_orientation = self.current_orientation
                self.get_logger().info(f'Finished moving forward: {self.current_position}')

        elif self.state == 'TURN':
            angle_error = self.turn_angle - self.angle_turned()
            desired_angular_speed = self.angular_pid.compute(self.turn_angle, self.angle_turned())
            msg.linear.x = 0.0
            msg.angular.z = desired_angular_speed

            if angle_error <= 0.05:  # Tolerance for stopping
                msg.angular.z = 0.0
                self.state = 'MOVE_FORWARD'
                self.sides_completed += 1
                self.initial_position = self.current_position
                self.get_logger().info(f'Finished turning: {self.current_orientation}')

                if self.sides_completed >= self.num_sides:
                    self.get_logger().info('Completed polygon path')
                    self.destroy_node()
                    rclpy.shutdown()

        self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)

    # Choose your shape here:
    num_sides = 3  # Change this to 1 for a line, 3 for a triangle, etc.
    side_length = 1.0  # Set the side length you want

    polygon_path_node = PolygonPathNode(num_sides, side_length)
    rclpy.spin(polygon_path_node)

if __name__ == '__main__':
    main()

