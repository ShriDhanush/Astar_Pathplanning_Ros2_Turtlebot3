import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import heapq

class DijkstraNode(Node):
    def __init__(self):
        super().__init__('dijkstra_node')

        # Create a publisher to send the path and cost
        self.publisher_ = self.create_publisher(String, 'dijkstra_result', 10)
        
        # Sample maze
        self.maze = [
            [0, 1, 0, 0, 0],
            [0, 1, 0, 1, 0],
            [0, 0, 0, 1, 0],
            [1, 1, 0, 0, 0],
            [0, 0, 0, 1, 0],
        ]
        
        # Starting and goal positions
        self.start = (0, 0)
        self.goal = (4, 4)

        # Run the Dijkstra algorithm
        self.run_dijkstra()

    def run_dijkstra(self):
        path, cost = self.dijkstra(self.maze, self.start, self.goal)
        result = f"Path: {path}, Cost: {cost}"
        self.publisher_.publish(String(data=result))
        self.get_logger().info(result)

    def dijkstra(self, maze, start, goal):
        rows, cols = len(maze), len(maze[0])
        visited = set()
        priority_queue = [(0, start)]  # (cost, (x, y))
        distances = {start: 0}
        previous_nodes = {start: None}

        while priority_queue:
            current_cost, current_node = heapq.heappop(priority_queue)

            # Stop if we reached the goal
            if current_node == goal:
                break

            if current_node in visited:
                continue

            visited.add(current_node)

            # Check adjacent nodes
            x, y = current_node
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:  # Up, Down, Left, Right
                neighbor = (x + dx, y + dy)
                if 0 <= neighbor[0] < rows and 0 <= neighbor[1] < cols and maze[neighbor[0]][neighbor[1]] == 0:
                    new_cost = current_cost + 1
                    if neighbor not in distances or new_cost < distances[neighbor]:
                        distances[neighbor] = new_cost
                        previous_nodes[neighbor] = current_node
                        heapq.heappush(priority_queue, (new_cost, neighbor))

        # Reconstruct the path from goal to start
        path = []
        current = goal
        while current is not None:
            path.append(current)
            current = previous_nodes[current]
        path.reverse()
        
        return path, distances[goal] if goal in distances else float('inf')


def main(args=None):
    rclpy.init(args=args)
    node = DijkstraNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

