import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from math import atan2, sqrt, pi
import heapq
import cv2

class AStarPathFollower(Node):
    def __init__(self):
        super().__init__('astar_path_follower')

        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)
        self.odom_subscription = self.create_subscription(Odometry, '/odom', self.odom_callback, 10)

        self.current_position = [0.0, 0.0]
        self.current_orientation = 0.0
        self.path = []
        self.current_index = 0

        # Load the map and plan the path
        self.map_grid, self.resolution, self.origin = self.load_map(
            '/home/dhanush/ros2_ws/src/agvrobot_description/agvrobot_description/maze.pgm',
            '/home/dhanush/ros2_ws/src/agvrobot_description/agvrobot_description/maze.yaml'
        )
        self.start = (5, 10)  # Update these coordinates based on your map
        self.goal = (250, 250)  # Update this based on your goal position

        self.plan_path()

        # Control loop timer
        self.timer = self.create_timer(0.1, self.timer_callback)

    def load_map(self, pgm_file, yaml_file):
        img = cv2.imread(pgm_file, cv2.IMREAD_GRAYSCALE)
        _, binary_map = cv2.threshold(img, 200, 1, cv2.THRESH_BINARY_INV)

        with open(yaml_file, 'r') as file:
            data = file.readlines()

        resolution = float([line for line in data if 'resolution' in line][0].split(': ')[1].strip())
        origin = [float(val) for val in [line for line in data if 'origin' in line][0].split(': ')[1].strip()[1:-1].split(',')]

        return binary_map, resolution, origin

    def heuristic(self, a, b):
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    def a_star(self, grid, start, goal):
        rows, cols = grid.shape
        open_set = [(0, start)]
        came_from = {}
        g_score = {start: 0}
        f_score = {start: self.heuristic(start, goal)}
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1)]

        while open_set:
            current_cost, current_node = heapq.heappop(open_set)

            if current_node == goal:
                break

            x, y = current_node
            for dx, dy in directions:
                neighbor = (x + dx, y + dy)

                if 0 <= neighbor[0] < rows and 0 <= neighbor[1] < cols and grid[neighbor[0], neighbor[1]] == 0:
                    move_cost = 1.4 if dx != 0 and dy != 0 else 1
                    tentative_g_score = g_score[current_node] + move_cost

                    if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                        came_from[neighbor] = current_node
                        g_score[neighbor] = tentative_g_score
                        f_score[neighbor] = tentative_g_score + self.heuristic(neighbor, goal)
                        heapq.heappush(open_set, (f_score[neighbor], neighbor))

        path = []
        if goal in came_from:
            current = goal
            while current is not None:
                path.append(current)
                current = came_from.get(current, None)
            path.reverse()

        return path

    def plan_path(self):
        self.path = self.a_star(self.map_grid, self.start, self.goal)
        self.get_logger().info(f'Path planned: {self.path}')
        # Initialize current index to start of path
        self.current_index = 0

    def odom_callback(self, msg):
        self.current_position = [msg.pose.pose.position.x, msg.pose.pose.position.y]
        orientation_q = msg.pose.pose.orientation
        self.current_orientation = self.euler_from_quaternion(orientation_q)

    def euler_from_quaternion(self, q):
        """Convert a quaternion into euler angles (roll, pitch, yaw)."""
        x = q.x
        y = q.y
        z = q.z
        w = q.w
        # Yaw (z-axis rotation)
        siny_cosp = 2.0 * (w * z + x * y)
        cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
        yaw = atan2(siny_cosp, cosy_cosp)
        return yaw

    def get_distance(self, point1, point2):
        return sqrt(pow((point1[0] - point2[0]), 2) + pow((point1[1] - point2[1]), 2))

    def get_angle_to_target(self, target):
        return atan2(target[1] - self.current_position[1], target[0] - self.current_position[0])

    def timer_callback(self):
        msg = Twist()

        if self.current_index < len(self.path):
            target = self.path[self.current_index]

            # Calculate the coordinates in the map space
            target_position = (
                target[1] * self.resolution + self.origin[0], 
                target[0] * self.resolution + self.origin[1]
            )

            distance_to_target = self.get_distance(self.current_position, target_position)
            angle_to_target = self.get_angle_to_target(target_position)
            angle_diff = angle_to_target - self.current_orientation

            # Normalize the angle difference
            angle_diff = (angle_diff + pi) % (2 * pi) - pi

            if abs(angle_diff) > 0.1:  # Allow some tolerance
                # Rotate to face the target
                msg.angular.z = 0.3 if angle_diff > 0 else -0.3
            elif distance_to_target > 0.1:
                # Move towards the target
                msg.linear.x = 0.2
            else:
                # Reached the target, move to the next waypoint
                self.current_index += 1
                self.get_logger().info(f'Moving to next waypoint: {target_position}')

        else:
            # Stop if we've reached the end of the path
            msg.linear.x = 0.0
            msg.angular.z = 0.0
            self.get_logger().info("Reached the end of the path!")

        self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)

    node = AStarPathFollower()
    rclpy.spin(node)

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

